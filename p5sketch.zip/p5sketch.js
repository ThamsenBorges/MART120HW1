scrpt.js 
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(245, 185, 95);
  circle(130, 132, 50)
  circle(270, 132, 50)
  rect(107, 90, 50, 5)
  rect(245, 90, 50, 5)
  triangle(200, 170, 240, 205, 186, 185)
  textSize(20);
  text('Thamsen Borges', 240, 395);
  text('Me, Myself, And I', 15, 30)
  line(100,75,15,160)
  line(90,75,15,150)
  line(80,75,15,140)
  point(200,180)
  rect(145, 240, 120, 8)
  line(97,270,97,87)
  line(97,87,300,87)
  line(300,87,300,270)
  line(300,270,97,270)
  point(200,183)
  point(205,180)
  line(312,75,385,140)
  line(302,75,385,150)
  line(292,75,385,160)
  line(292 ,75,100,75)
  line(315 ,75,75,75)

}